package com.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.database.DBConnection;
import com.entity.Employee;


public class DAO {
    DBConnection dbConnection = null;
    Connection connection = null;

    List<Employee> employeeList=new ArrayList<Employee>();
    
    public List<Employee> callProcedure(long employeeId) {
        try {
            dbConnection = new DBConnection();
            connection = dbConnection.getConnection();

            // Prepare the stored procedure call
            String queryProcedure ="execute  empAA11 @employeeId=?";
            CallableStatement callableStatement = connection.prepareCall(queryProcedure);
            callableStatement.setLong(1, employeeId);

            // Execute the stored procedure
            ResultSet resultSet = callableStatement.executeQuery();

            // Process the results for employee
            while (resultSet.next()) {
                Employee employee = new Employee();
                employee.setEmployeeId(resultSet.getLong(1));
                employee.setName(resultSet.getString(2));
                employee.setAddress(resultSet.getString(3));
                employee.setGender(resultSet.getByte(4));
                employee.setSalary(resultSet.getDouble(5));
                employee.setBirthDate(resultSet.getDate(6));
                
                employeeList.add(employee);
            }

            // Close resources
            resultSet.close();
            callableStatement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return employeeList;
    }
}
