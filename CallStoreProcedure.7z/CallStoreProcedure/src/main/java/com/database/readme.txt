<Resource auth="Container" driverClassName="com.microsoft.sqlserver.jdbc.SQLServerDriver" logAbandoned="false" maxActive="10" maxIdle="5" maxWait="10000" name="test" password="test" removeAbandoned="true" removeAbandonedTimeout="100" type="javax.sql.DataSource" url="jdbc:sqlserver://100.111.111.42;Database=test" username="test"/>
SQL server Credential
Server Name/Address=100.111.111.42
username=test
password=test
Default Database=test

