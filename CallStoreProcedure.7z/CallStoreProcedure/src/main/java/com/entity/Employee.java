package com.entity;

import java.util.Date;

public class Employee {
	public long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public byte getGender() {
		return gender;
	}
	public void setGender(byte gender) {
		this.gender = gender;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	private long employeeId;
	private String name;
	@Override
	public String toString() {
		return "Procedure [employeeId=" + employeeId + ", name=" + name + ", address=" + address + ", gender=" + gender
				+ ", salary=" + salary + ", birthDate=" + birthDate + "]";
	}
	private String address;
	public Employee(long employeeId, String name, String address, byte gender, double salary, Date birthDate) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.address = address;
		this.gender = gender;
		this.salary = salary;
		this.birthDate = birthDate;
	}
	private byte gender;
	private double salary;
	private Date birthDate;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
}
