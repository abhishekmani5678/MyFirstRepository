package com.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DAO;
import com.entity.Employee;


@WebServlet("/ProcedureServlet")
public class ProcedureServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Getting Data from clent Side
		long employeeId=Long.parseLong(request.getParameter("employeeId"));
		
		
		
	DAO dao=new DAO();
	List<Employee> list=dao.callProcedure(employeeId);
		
		for(Employee p: list) {
			System.out.println("employeeId ="+p.getEmployeeId());
			System.out.println("Employee Name"+p.getName());
			System.out.println("Employee Address"+p.getAddress());
			System.out.println("Employee Gender"+p.getGender());
			System.out.println("Employee Salary"+p.getSalary());
			System.out.println("Employee BirthDate"+p.getBirthDate());
			
		}
	}



}
